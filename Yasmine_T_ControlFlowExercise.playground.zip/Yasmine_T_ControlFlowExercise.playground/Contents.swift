import UIKit
var seconds = "0"

for _ in 0...180 {
    print("Timer : \(seconds)")
}
